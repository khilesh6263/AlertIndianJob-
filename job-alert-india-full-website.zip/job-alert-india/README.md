# Job Alert India — full-stack starter

Responsive website for Government jobs, Private jobs and Work From Home listings. Includes search/filter, sample job cards, email OTP signup, user session endpoints, MongoDB storage and protected admin publishing API.

## Run locally
1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and fill MongoDB, JWT, admin and SMTP settings.
4. Run `npm start`, then open `http://localhost:3000`.

Sample listings display even before MongoDB is connected. Signup and job publishing need MongoDB. Email OTP needs SMTP credentials. The included sample listings are illustrative; verify every vacancy on the official site.

## Admin API
Login: `POST /api/admin/login` with JSON `{ "email":"...", "password":"..." }`. Use returned token as `Authorization: Bearer TOKEN` on `POST /api/admin/jobs`. Required job fields: title, company, applyUrl (HTTPS). `DELETE /api/admin/jobs/:id` removes a listing.

## Deploy
Recommended simple setup: deploy the complete Node app as one Render Web Service. Push project to GitHub (never upload `.env`), create MongoDB Atlas database, create Render Web Service, set build command `npm install`, start command `npm start`, and add all `.env` values in Render Environment settings.

## Before public launch
This is a starter project, not a security-audited production website. Email OTP is implemented; SMS OTP is NOT wired into signup, so dual OTP is not yet active. OTPs are stored in server memory and disappear on restart; use Redis/persistent TTL storage in production. Add CSRF protection, stronger abuse controls, monitoring, backups, account deletion and security review. Keep admin credentials private. Replace privacy/terms templates with reviewed policies and real contact details. Never post unverified vacancies, fake salary claims or application-fee claims. Follow hosting providers' age/account terms; if adult account ownership is required, have a parent/guardian manage it.
